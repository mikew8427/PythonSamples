#
# Imports required for this process to run
import http.client, urllib.parse, json
#
# Retrieve the key and secret form the integrations section of setup API's
#
mykey='MwbQq59aDJunYXtbsHexRyJT99H7MBEB'
mysecret='QeAhW5usmtZ5MqdP34kG5R5mdQ4WUeDfZGPRwRets8hwVJ56CrGJBqRX7McsJ8qp'
#
# url is used im the authorization call to get the access token
# url2 is used to make the request for devices in a tenant 
#
url='/auth/oauth/token'
url2='/api/v2/tenants/client_2633/devices/minimal'
#
# Setup the params for the GetAuthorization process. The headers content can be collected form the API sample in 
# the API section of the integrations (CURL Example)
#
params = urllib.parse.urlencode({'grant_type' : 'client_credentials', 'client_id': mykey, 'client_secret': mysecret})
headers = {"Content-type": "application/x-www-form-urlencoded", "Accept": "application/json"}
#
# Make the connetion and POST the request for the access token
#
conn = http.client.HTTPSConnection("tse-env1.api.try.opsramp.com")
conn.request("POST", url, params, headers)
response = conn.getresponse()
if response.status > 399 :
    print ("Unable to get the access token" , response.status, response.reason)
    exit()
#
# Must be good so setup the data from the json response. 
# Format the access "ac" token to be used in the next call
#
data = response.read()
load_json=json.loads(data)
ac= "Bearer " + load_json['access_token']
print("Access Token returned: ", ac)
#
# Now setup to get the devices for thsi client tenant
#
headers = {"Content-type": "application/x-www-form-urlencoded", "Accept": "application/json", "Authorization": ac}
conn.request("GET", url2, "", headers)
response = conn.getresponse()
if response.status > 399 :
    print ("Unable to get the device list" , response.status, response.reason)
    exit()
data = response.read()
print("Data returned ", data)