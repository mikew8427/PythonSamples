# You will need a file named keys.txt in the working dirctory
# you will need a file named urls.txt
# Imports required for this process to run
import http.client, urllib.parse, json, sys
import constant
#
# Retrieve the key and secret form the integrations section of setup API's
# Pass in the specific client ID
#
def loadkeys(clientID):
    try :
        with open(constant.KEY_filename) as f:
            a=json.load(f)
            return a[clientID]
    except : 
        print("Critical Error: No file named keys.txt in working directory OR Tenant ID not found")  
        exit()      
#
# Load in the supported URLS for this process
#
def loadurls():
    try :
        with open(constant.URL_filename) as f:
            a=json.load(f)
            return a
    except : 
        print("Critical Error: No file named urls.txt in working directory")  
        exit()      
#
# Test the input parms: You need to add the Tenant ID you wish to use for the API run
#
#
if len(sys.argv) < 3 :
    print("Program terminating : You need to supply a tenant ID and API tail example: RunApi.py client_2633 devices")
    exit()
p1=sys.argv[1]
p2=sys.argv[2]
print("Constants are ", constant.KEY_key, constant.KEY_secret)
# Setup the params for the GetAuthorization process. The headers content can be collected form the API sample in 
# the API section of the integrations (CURL Example)
#
keys=loadkeys(p1)
urls=loadurls()
try :
    mykey=keys[constant.KEY_key]
    mysecret=keys[constant.KEY_secret]
    url=urls[constant.KEY_token]
except : 
    print("Malformed keys.txt or urls.txt file")
    exit()
params = urllib.parse.urlencode({'grant_type' : 'client_credentials', 'client_id': mykey, 'client_secret': mysecret})
headers = {"Content-type": "application/x-www-form-urlencoded", "Accept": "application/json"}
#
# Make the connetion and POST the request for the access token
#
conn = http.client.HTTPSConnection("tse-env1.api.try.opsramp.com")
conn.request("POST", url, params, headers)
response = conn.getresponse()
if response.status > 399 :
    print ("Unable to get the access token" , response.status, response.reason)
    exit()
#
# Must be good so setup the data from the json response. 
# Format the access "ac" token to be used in the next call
#
data = response.read()
load_json=json.loads(data)
ac= "Bearer " + load_json[constant.KEY_accesstoken]
print("Access Token returned: ", ac)
#
# Now setup to get the devices for thsi client tenant
#
url=urls[p2]
url=url.replace(constant.Template_tenant,p1)
headers = {"Content-type": "application/x-www-form-urlencoded", "Accept": "application/json", "Authorization": ac}
conn.request("GET", url, "", headers)
response = conn.getresponse()
if response.status > 399 :
    print ("Unable to get the device list" , response.status, response.reason)
    exit()
data = response.read()
print("Data returned ", data)